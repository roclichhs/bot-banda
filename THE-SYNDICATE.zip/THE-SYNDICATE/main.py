import discord
from discord.ext import commands
from flask import Flask
import threading
import os

# Configurar intents con privilegios
intents = discord.Intents.default()
intents.members = True
intents.message_content = True

# Crear bot con prefijo !
bot = commands.Bot(command_prefix="!", intents=intents)

# IDs de tus canales
CANAL_ENTRADA_ID = 1225959617494782003
CANAL_SALIDA_ID = 1225959667444879441

# Evento al iniciar el bot
@bot.event
async def on_ready():
    print(f"{bot.user} está conectado y funcionando.")

# Evento al entrar un miembro
@bot.event
async def on_member_join(member):
    canal = bot.get_channel(CANAL_ENTRADA_ID)
    if canal:
        embed = discord.Embed(
            title="⚫ BIENVENIDO A THE SYNDICATE ⚫",
            description=f"{member.mention}, nos alegra tenerte aquí.",
            color=0x000000
        )
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        await canal.send(embed=embed)

# Evento al salir un miembro
@bot.event
async def on_member_remove(member):
    canal = bot.get_channel(CANAL_SALIDA_ID)
    if canal:
        embed = discord.Embed(
            title="⚫ GRACIAS POR TUS SERVICIOS EN THE SYNDICATE ⚫",
            description=f"{member.name} ha dejado el servidor.",
            color=0x2f3136
        )
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        await canal.send(embed=embed)

# Comando de prueba
@bot.command()
async def ping(ctx):
    await ctx.send("🏓 ¡Estoy vivo!")

# Flask web server para mantener Replit despierto
app = Flask('')

@app.route('/')
def home():
    return "Bot corriendo correctamente."

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = threading.Thread(target=run)
    t.daemon = True
    t.start()

# Ejecutar servidor y bot
keep_alive()
bot.run(os.getenv("TOKEN"))